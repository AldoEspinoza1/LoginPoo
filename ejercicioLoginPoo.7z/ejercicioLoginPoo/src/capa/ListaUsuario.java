/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package capa;

import java.util.Vector;
import javax.swing.JOptionPane;

/**
 *
 * @author Aldo
 */
public class ListaUsuario {
    private static Vector<Usuario> datos = new Vector<Usuario>();
    
    public static void agregar (Usuario obj){
        Usuario usu = new Usuario();
        String usuario = usu.getusuario();
        String contraseña = usu.getcontraseña();
        int pos = Usuario.verificarLogueo(usuario, contraseña);
        if (pos != -1) {
            JOptionPane.showMessageDialog(null, "Lo lamento pero este usuario ya existe");
        }
        else{
            datos.addElement(obj);
        }
        
    }
    public static void eliminar(int pos){
        datos.removeElementAt(pos);
    }
    public static Vector mostrar(){
        return datos;
    }
}