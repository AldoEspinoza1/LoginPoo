/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package capa;

import java.util.Vector;

/**
 *
 * @author Aldo
 */
public class Usuario {

    private String usuario;
    private String contraseña;
    private String nombre;
    private String edad;

    public String getusuario() {
        return usuario;
    }

    public void setusuario(String usuario) {
        this.usuario = usuario;
    }

    public String getcontraseña() {
        return contraseña;
    }

    public void setcontraseña(String contraseña) {
        this.contraseña = contraseña;
    }

    public String getnombre() {
        return nombre;
    }

    public void setnombre(String nombre) {
        this.nombre = nombre;
    }

    public String getedad() {
        return edad;
    }

    public void setedad(String edad) {
        this.edad = edad;
    }

    public static Vector mostrar() {
        return ListaUsuario.mostrar();
    }

    public static int verificarUsuarioNuevo(String usuario) {
        Vector lista = mostrar();
        Usuario obj;
        for (int i = 0; i < lista.size(); i++) {
            obj = (Usuario) lista.elementAt(i);
            if (obj.getusuario().equalsIgnoreCase(usuario)) {
                return i;
            }
        }
        return -1;
    }

    public static int verificarLogueo(String usuario, String contraseña) {
        Vector lista = mostrar();
        Usuario obj;
        for (int i = 0; i < lista.size(); i++) {
            obj = (Usuario) lista.elementAt(i);
            if (obj.getusuario().equalsIgnoreCase(usuario) && obj.getcontraseña().equalsIgnoreCase(contraseña)) {
                return i;
            }
        }
        return -1;

    }
}